# CUDA-Accelerated Grayscale Image Processing

This project implements a GPU-accelerated 3×3 box blur for grayscale PGM images
using CUDA C++. Each CUDA thread computes one output pixel, allowing many pixels
to be processed in parallel.

## Features

- CUDA kernel with a 2D grid and 2D thread blocks.
- Supports grayscale PGM `P5` (binary) and `P2` (ASCII) images.
- Handles image boundaries by averaging only valid neighboring pixels.
- Accepts input and output directories as command-line arguments.
- Checks CUDA API errors and reports file-processing failures.

## Requirements

- NVIDIA GPU with a supported CUDA driver.
- NVIDIA CUDA Toolkit (`nvcc`).
- C++17-capable host compiler.

## Build

From the repository root:

```bash
make
```

Or compile directly:

```bash
nvcc -O2 -std=c++17 src/box_blur.cu -o box_blur
```

## Run

```bash
./box_blur <input_directory> <output_directory>
```

Example:

```bash
./box_blur samples/input samples/output
```

The program processes files with the `.pgm` extension in the input directory and
writes blurred images with the same filenames into the output directory.

## Algorithm

For each pixel, the kernel accumulates its valid neighbors in a 3×3 window and
divides by the number of valid samples. At borders and corners, out-of-image
neighbors are skipped. Integer rounding is applied when storing the average.

## Sample data

`samples/input/sample.pgm` is a small generated grayscale test image. The
`samples/cpu_reference/` directory contains a CPU-generated reference output
for checking the filter's expected behavior. It is a reference artifact, not
evidence that the CUDA executable was run.

## Validation and execution evidence

Build and run this project on a CUDA-enabled machine. Keep the actual terminal
output and generated output images. For the course's proof-of-execution upload,
include genuine logs/screenshots and output images from your own run; do not
represent the CPU reference image as a GPU execution result.

## Limitations

- Only grayscale PGM files with maximum sample value at most 255 are supported.
- The program processes files in the specified input directory (not recursively).
- Performance measurements depend on the GPU, driver, and image sizes.
