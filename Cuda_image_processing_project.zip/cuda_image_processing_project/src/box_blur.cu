#include <cuda_runtime.h>

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

#define CUDA_CHECK(call)                                                        \
    do {                                                                        \
        cudaError_t err = (call);                                               \
        if (err != cudaSuccess) {                                               \
            throw std::runtime_error(std::string("CUDA error: ") +              \
                                     cudaGetErrorString(err));                   \
        }                                                                       \
    } while (0)

struct PgmImage {
    int width = 0;
    int height = 0;
    std::vector<unsigned char> pixels;
};

static std::string readToken(std::istream& input) {
    std::string result;
    char ch = '\0';

    while (input.get(ch)) {
        if (std::isspace(static_cast<unsigned char>(ch))) {
            continue;
        }
        if (ch == '#') {
            std::string ignored;
            std::getline(input, ignored);
            continue;
        }
        result.push_back(ch);
        break;
    }

    while (input.get(ch)) {
        if (std::isspace(static_cast<unsigned char>(ch))) {
            break;
        }
        if (ch == '#') {
            std::string ignored;
            std::getline(input, ignored);
            break;
        }
        result.push_back(ch);
    }

    if (result.empty()) {
        throw std::runtime_error("Unexpected end of PGM header");
    }
    return result;
}

static PgmImage readPgm(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("Cannot open input image: " + path.string());
    }

    const std::string magic = readToken(input);
    if (magic != "P5" && magic != "P2") {
        throw std::runtime_error("Unsupported image format; use PGM P5 or P2");
    }

    PgmImage image;
    image.width = std::stoi(readToken(input));
    image.height = std::stoi(readToken(input));
    const int maxValue = std::stoi(readToken(input));

    if (image.width <= 0 || image.height <= 0 ||
        maxValue <= 0 || maxValue > 255) {
        throw std::runtime_error("Invalid PGM dimensions or max value");
    }

    const size_t pixelCount =
        static_cast<size_t>(image.width) * static_cast<size_t>(image.height);
    image.pixels.resize(pixelCount);

    if (magic == "P5") {
        input.read(reinterpret_cast<char*>(image.pixels.data()),
                   static_cast<std::streamsize>(pixelCount));
        if (input.gcount() != static_cast<std::streamsize>(pixelCount)) {
            throw std::runtime_error("PGM pixel data is incomplete");
        }
        if (maxValue != 255) {
            for (auto& pixel : image.pixels) {
                pixel = static_cast<unsigned char>(
                    (static_cast<int>(pixel) * 255 + maxValue / 2) / maxValue);
            }
        }
    } else {
        for (size_t i = 0; i < pixelCount; ++i) {
            const int value = std::stoi(readToken(input));
            if (value < 0 || value > maxValue) {
                throw std::runtime_error("PGM pixel value is out of range");
            }
            image.pixels[i] = static_cast<unsigned char>(
                (value * 255 + maxValue / 2) / maxValue);
        }
    }

    return image;
}

static void writePgm(const fs::path& path, const PgmImage& image) {
    std::ofstream output(path, std::ios::binary);
    if (!output) {
        throw std::runtime_error("Cannot write output image: " + path.string());
    }

    output << "P5\n" << image.width << ' ' << image.height << "\n255\n";
    output.write(reinterpret_cast<const char*>(image.pixels.data()),
                 static_cast<std::streamsize>(image.pixels.size()));
    if (!output) {
        throw std::runtime_error("Failed while writing: " + path.string());
    }
}

__global__ void boxBlur3x3(const unsigned char* input,
                           unsigned char* output,
                           int width,
                           int height) {
    const int x = blockIdx.x * blockDim.x + threadIdx.x;
    const int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x >= width || y >= height) {
        return;
    }

    int sum = 0;
    int sampleCount = 0;

    for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
            const int neighborX = x + dx;
            const int neighborY = y + dy;

            if (neighborX >= 0 && neighborX < width &&
                neighborY >= 0 && neighborY < height) {
                sum += input[neighborY * width + neighborX];
                ++sampleCount;
            }
        }
    }

    output[y * width + x] = static_cast<unsigned char>(
        (sum + sampleCount / 2) / sampleCount);
}

static void blurOnGpu(PgmImage& image) {
    const size_t bytes = image.pixels.size() * sizeof(unsigned char);
    unsigned char* deviceInput = nullptr;
    unsigned char* deviceOutput = nullptr;

    try {
        CUDA_CHECK(cudaMalloc(&deviceInput, bytes));
        CUDA_CHECK(cudaMalloc(&deviceOutput, bytes));
        CUDA_CHECK(cudaMemcpy(deviceInput, image.pixels.data(), bytes,
                              cudaMemcpyHostToDevice));

        const dim3 block(16, 16);
        const dim3 grid((image.width + block.x - 1) / block.x,
                        (image.height + block.y - 1) / block.y);

        boxBlur3x3<<<grid, block>>>(deviceInput, deviceOutput,
                                   image.width, image.height);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaDeviceSynchronize());
        CUDA_CHECK(cudaMemcpy(image.pixels.data(), deviceOutput, bytes,
                              cudaMemcpyDeviceToHost));
    } catch (...) {
        if (deviceInput != nullptr) cudaFree(deviceInput);
        if (deviceOutput != nullptr) cudaFree(deviceOutput);
        throw;
    }

    CUDA_CHECK(cudaFree(deviceInput));
    CUDA_CHECK(cudaFree(deviceOutput));
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0]
                  << " <input_directory> <output_directory>\n";
        return 2;
    }

    try {
        const fs::path inputDirectory(argv[1]);
        const fs::path outputDirectory(argv[2]);

        if (!fs::is_directory(inputDirectory)) {
            throw std::runtime_error(
                "Input path is not a directory: " + inputDirectory.string());
        }
        fs::create_directories(outputDirectory);

        int processedCount = 0;
        for (const auto& entry : fs::directory_iterator(inputDirectory)) {
            if (!entry.is_regular_file()) {
                continue;
            }

            std::string extension = entry.path().extension().string();
            std::transform(extension.begin(), extension.end(), extension.begin(),
                [](unsigned char c) {
                    return static_cast<char>(std::tolower(c));
                });

            if (extension != ".pgm") {
                continue;
            }

            PgmImage image = readPgm(entry.path());
            blurOnGpu(image);

            const fs::path outputPath =
                outputDirectory / entry.path().filename();
            writePgm(outputPath, image);

            std::cout << "Processed " << entry.path().filename().string()
                      << " (" << image.width << "x" << image.height << ") -> "
                      << outputPath.string() << '\n';
            ++processedCount;
        }

        std::cout << "Finished. Images processed: " << processedCount << '\n';
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }

    return 0;
}
